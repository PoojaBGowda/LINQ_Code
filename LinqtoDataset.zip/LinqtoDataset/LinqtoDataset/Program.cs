﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace LinqtoDataset
{
    class Program
    {
        static void Main(string[] args)
        {
            string connection = ConfigurationManager.ConnectionStrings["LinqtoDataset.Properties.Settings.NorthwindConnectionString"].ToString();

            DataClasses1DataContext db = new DataClasses1DataContext(connection);
            
            string sqlSelect = "SELECT * FROM Employees;";

            SqlDataAdapter da = new SqlDataAdapter(sqlSelect, connection);

            da.TableMappings.Add("Table", "Employees");

            DataSet ds = new DataSet();
            da.Fill(ds);

            DataTable dt = ds.Tables["Employees"];

            var query = from d in dt.AsEnumerable()
                        select new
                        {
                            EmployeeID = d.Field<int>("EmployeeID"),
                            LastName = d.Field<string>("LastName")
                        };


            foreach (var q in query)
            {
                Console.WriteLine("Employee Id = {0} , LastName = {1} ",
                                  q.EmployeeID, q.LastName);
            }


            /*Insert into the dataset*/

            DataRow row = dt.NewRow();
            row["EmployeeID"] = 34;
            row["FirstName"] = "Harika";
            row["LastName"] = "Nallagatla";
            dt.Rows.Add(row);
            ds.AcceptChanges();

            Console.WriteLine("---------After inserting the data intothe dataset---------");

            DataTable dtchanged = ds.Tables["Employees"];

            var query1 = from d in dtchanged.AsEnumerable()
                         select new
                         {
                             EmployeeID = d.Field<int>("EmployeeID"),
                             LastName = d.Field<string>("LastName")
                         };                 

            foreach (var q in query1)
            {
                Console.WriteLine("Employee Id = {0} , LastName = {1} ",
                                  q.EmployeeID, q.LastName);
            }

            /*Updating the dataset*/

            //var updaterecord = dt.AsEnumerable().Where(e => e.Field<string>("LastName") == "Nallagatla");

            var updaterecord = from d in dt.AsEnumerable()
                               where d.Field<string>("LastName") == "Nallagatla"
                               select d;
            foreach (var item in updaterecord)
            {
                item.SetField("LastName", "Lakshmi");
            }

            ds.AcceptChanges();

            Console.WriteLine("-----------After updating the dataset------");

            DataTable dtchanged1 = ds.Tables["Employees"];

            var query2 = from d in dtchanged1.AsEnumerable()
                         select new
                         {
                             EmployeeID = d.Field<int>("EmployeeID"),
                             LastName = d.Field<string>("LastName")
                         };


            foreach (var q in query2)
            {
                Console.WriteLine("Employee Id = {0} , LastName = {1} ",
                                  q.EmployeeID, q.LastName);
            }


            /*Deleting the record from the dataset*/

            var deleterecord = dt.AsEnumerable().Where(e => e.Field<string>("LastName") == "Lakshmi");

            foreach (var item in deleterecord)
            {
                item.Delete();
            }
            ds.AcceptChanges();

            Console.WriteLine( "------------After deleting the record from the dataset---------");

            DataTable dtchanged2 = ds.Tables["Employees"];

            var query3 = from d in dtchanged2.AsEnumerable()
                         select new
                         {
                             EmployeeID = d.Field<int>("EmployeeID"),
                             LastName = d.Field<string>("LastName")
                         };


            foreach (var q in query3)
            {
                Console.WriteLine("Employee Id = {0} , LastName = {1} ",
                                  q.EmployeeID, q.LastName);
            }


            Console.WriteLine("\nPress any key to continue.");
            Console.ReadKey();
        }
    }
}