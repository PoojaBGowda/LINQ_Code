﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Select
{
    class Program
    {
        static void Main(string[] args)
        {

            ////Select - Simple 1
            //         int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

            //         var numsPlusOne =
            //             from n in numbers
            //             select n + 1;

            //         Console.WriteLine("Numbers + 1:");
            //         foreach (var i in numsPlusOne)
            //         {
            //             Console.WriteLine(i);
            //         }

            ////Select - Simple 2

            //DataClasses1DataContext db = new DataClasses1DataContext();
            //List<Product> products = db.GetTable<Product>().ToList();

            //var productNames =
            //    from p in products
            //    select p.ProductName;

            //Console.WriteLine("Product Names:");
            //foreach (var productName in productNames)
            //{
            //    Console.WriteLine(productName);
            //}

            ////  Select Transformation

            //int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //string[] strings = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };

            //var textNums =
            //    from n in numbers
            //    select strings[n];

            //Console.WriteLine("Number strings:");
            //foreach (var s in textNums)
            //{
            //    Console.WriteLine(s);
            //}


            ////Select -Anonymous Type-1

            //string[] words = { "aPPLE", "BlUeBeRrY", "cHeRry" };

            //var upperLowerWords =
            //    from w in words
            //    select new { Upper = w.ToUpper(), Lower = w.ToLower() };

            //foreach (var ul in upperLowerWords)
            //{
            //    Console.WriteLine("Uppercase: {0}, Lowercase: {1}", ul.Upper, ul.Lower);
            //}

            ////    Select -Indexed

            //int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

            //var numsInPlace = numbers.Select((num, index) => new { Num = num, InPlace = (num == index) });

            //Console.WriteLine("Number: In-place?");
            //foreach (var n in numsInPlace)
            //{
            //    Console.WriteLine("{0}: {1}", n.Num, n.InPlace);
            //}

            ////Select Filtered

            //         int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //         string[] digits = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };

            //         var lowNums =
            //             from n in numbers
            //             where n < 5
            //             select digits[n];

            //         Console.WriteLine("Numbers < 5:");
            //         foreach (var num in lowNums)
            //         {
            //             Console.WriteLine(num);
            //          }

            //// SelectMany - Compound from 1

            int[] numbersA = { 0, 2, 4, 5, 6, 8, 9 };
            int[] numbersB = { 1, 3, 5, 7, 8 };

            var pairs =
                from a in numbersA
                from b in numbersB
                where a < b
                select new { a, b };

            Console.WriteLine("Pairs where a < b:");
            foreach (var pair in pairs)
            {
                Console.WriteLine("{0} is less than {1}", pair.a, pair.b);
            }



        }

    }
}