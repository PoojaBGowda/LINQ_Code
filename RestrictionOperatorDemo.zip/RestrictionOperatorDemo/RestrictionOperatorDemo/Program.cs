﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestrictionOperatorDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

            //var lowNums =
            //    from n in numbers
            //    where n < 5
            //    select n;

            //Console.WriteLine("Numbers < 5:");
            //foreach (var x in lowNums)
            //{
            //    Console.WriteLine(x);
            //}

            //DataClasses1DataContext db = new DataClasses1DataContext();
            //var result = from data in db.Employees
            //             where data.Country == "USA"
            //             select data.FirstName;

            //    Console.WriteLine(result);



            //DataClasses1DataContext db = new DataClasses1DataContext();
            //var result = from a in db.Employees
            //             where a.EmployeeID > 1 || a.Country == "USA"
            //             select a.FirstName;
            //foreach (var item in result)
            //{
            //    Console.WriteLine(item);
            //}


            DataClasses1DataContext db = new DataClasses1DataContext();
            var result = from a in db.Employees
                         where a.EmployeeID == 1
                         select a;
            foreach (var item in result)
            {
                foreach (var itemresult in item.FirstName)
                {
                    Console.Write(itemresult);
                }

            }


                //       string[] digits = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
                //       DataClasses1DataContext db = new DataClasses1DataContext();
                //       var shortDigits = digits.Where((digit, Value) => digit.Length > Value);
                //       Console.WriteLine("Short digits:");
                //       foreach (var d in shortDigits)
                //       {
                //           Console.WriteLine($"The word {d} is shorter than its value.");
                //       }

            }
    }
}