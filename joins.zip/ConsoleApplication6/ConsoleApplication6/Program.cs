﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Join
{
    class Program
    {
        public static void Main(string[] args)
        {
            //using sql join operator(left outer join)
            //            var result = from e in Employee.GetAllEmployees()
            //                         join d in Department.GetAllDepartment()
            //on e.DepartmentID equals d.ID into eGroup
            //                         from d in eGroup.DefaultIfEmpty()
            //                         select new
            //                         {
            //                             EmployeeName = e.Name,
            //                             DepartmentName =d == null ? "No Department" : d.Name
            //                         };
            //foreach (var v in result)
            //{
            //    Console.WriteLine(v.EmployeeName + "\t" + v.DepartmentName);
            //}
            //using extension method(left outer join)

            var result = Employee.GetAllEmployees().GroupJoin(Department.GetAllDepartment(),
                e => e.DepartmentID,
            d => d.ID,
            (Emp, Dept) => new
            {
                Emp,
                Dept
            })
            .SelectMany(z => z.Dept.DefaultIfEmpty(),
            (a, b) => new
            {
                EmployeeName = a.Emp.Name,
                DepartmentName = b == null ? "No Department" : b.Name,
            });
            foreach (var v in result)
            {
                Console.WriteLine(v.EmployeeName + "\t" + v.DepartmentName);
            }
            // using sql join operator(cross join)
            //var result = from e in Employee.GetAllEmployees()
            //             from d in Department.GetAllDepartment()
            //                  //swap



            //             select new
            //             {
            //                 e,
            //                 d
            //             };
            //foreach (var v in result)
            //{
            //    Console.WriteLine(v.e.Name + "\t" + v.d.Name);
            //}
            //using extension method1(cross join)
            //var result = Employee.GetAllEmployees().SelectMany(e => Department.GetAllDepartment(),
            //    (e, d) => new { e, d });
            //foreach (var v in result)
            //{
            //    Console.WriteLine(v.e.Name + "\t" + v.d.Name);
            //}

            //using extension method2(cross join)
            //var result = Employee.GetAllEmployees().Join(Department.GetAllDepartment(),
            //    e => true,
            //    d => true,
            //    (e, d) => new { e, d });
            //foreach (var v in result)
            //{
            //    Console.WriteLine(v.e.Name + "\t" + v.d.Name);
            //}


            //using sql join operator(Group Join)
            //var EmployeeByDepartment = from d in Department.GetAllDepartment()
            //                           join e in Employee.GetAllEmployees() on d.ID equals e.DepartmentID into eGroup
            //                           select new
            //                           {
            //                               Department = d,
            //                               Employee = eGroup
            //                           };
            //using Extension method
            //var EmployeeByDepartment = Department.GetAllDepartment().GroupJoin(Employee.GetAllEmployees(),
            //d => d.ID,
            //e => e.DepartmentID,
            //(department, employee) => new
            //{
            //    Department = department,
            //    Employee = employee
            //});

            //foreach (var department in EmployeeByDepartment)
            //{
            //    Console.WriteLine(department.Department.Name);
            //    foreach (var employee in department.Employee)
            //    {
            //        Console.WriteLine(" " + employee.Name);

            //    }
            //    Console.WriteLine();
            //}


        }
    }
}
