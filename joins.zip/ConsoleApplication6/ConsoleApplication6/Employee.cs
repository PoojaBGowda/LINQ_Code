﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Join
{
    public class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int DepartmentID { get; set; }

        public static List<Employee> GetAllEmployees()
        {
            return new List<Employee>()
            {
                new Employee {ID=1,Name="Mark",DepartmentID=1 },
                new Employee {ID=2,Name="John",DepartmentID=2 },
                new Employee {ID=3,Name="Roman",DepartmentID=1 },
                new Employee {ID=4,Name="Dean",DepartmentID=2 },
                new Employee {ID=5,Name="Seth",DepartmentID=1 },
                new Employee {ID=6,Name="Brock",DepartmentID=1 },
                new Employee {ID=7,Name="Rock",DepartmentID=2 },
                new Employee {ID=8,Name="Shaun",DepartmentID=1 },
                new Employee {ID=9,Name="Adi"},
                new Employee {ID=10,Name="Rick" },
            };
        }
    }
}