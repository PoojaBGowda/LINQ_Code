﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace misilleneousequalAll_demo1
{
    class Program
    {
        static void Main(string[] args)
        {
            IList<string> strList1 = new List<string>() { "One", "Two", "Three", "Four", "Three" };

            IList<string> strList2 = new List<string>() { "One", "Two", "Three", "Four", "Three" };

            bool isEqual = strList1.SequenceEqual(strList2);

            Console.WriteLine(isEqual);

            Console.ReadLine();
        }
    }
}
