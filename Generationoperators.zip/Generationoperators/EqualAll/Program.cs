﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EqualAll
{
    class Program
    {
       /* static void Main(string[] args)
        {
            IList<string> strList1 = new List<string>() { "One", "Two", "Three", "Four", "Three" };

            IList<string> strList2 = new List<string>() { "One", "Two", "Three", "Four", "Three" };

            bool isEqual = strList1.SequenceEqual(strList2);

            Console.WriteLine(isEqual);

            Console.ReadLine();
        }*/

      /*  public static void Main()
        {
            IList<string> strList1 = new List<string>() { "One", "Two", "Three", "Four", "Three" };

            IList<string> strList2 = new List<string>() { "Two", "One", "Three", "Four", "Three" };

            bool isEqual = strList1.SequenceEqual(strList2);

            Console.WriteLine(isEqual);

            Console.ReadLine();


        }*/
       /* public static void Main()
        {
            Student std = new Student() { StudentID = 1, StudentName = "Bill" };

            IList<Student> studentList1 = new List<Student>() { std };

            IList<Student> studentList2 = new List<Student>() { std };

            bool isStudentsEqual = studentList1.SequenceEqual(studentList2); // returns true

            Console.WriteLine(isStudentsEqual);

            Student std1 = new Student() { StudentID = 1, StudentName = "Bill" };

            Student std2 = new Student() { StudentID = 1, StudentName = "Bill" };

            IList<Student> studentList3 = new List<Student>() { std1 };

            IList<Student> studentList4 = new List<Student>() { std2 };

            isStudentsEqual = studentList3.SequenceEqual(studentList4); // returns false

            Console.WriteLine(isStudentsEqual);

            Console.ReadLine();

        }

    }
    public class Student
    {
        public int StudentID { get; set; }

        public string StudentName { get; set; }
    }*/
         static void Main(string[] args)
         {
             IList<Student> studentList1 = new List<Student>() {
             new Student() { StudentID = 1, StudentName = "John" },
             new Student() { StudentID = 2, StudentName = "Steve" },
             new Student() { StudentID = 3, StudentName = "Bill" },
             new Student() { StudentID = 4, StudentName = "Ram"  },
             new Student() { StudentID = 5, StudentName = "Ron" }
         };

             IList<Student> studentList2 = new List<Student>() {
             new Student() { StudentID = 1, StudentName = "John" },
             new Student() { StudentID = 2, StudentName = "Steve" },
             new Student() { StudentID = 3, StudentName = "Bill" },
             new Student() { StudentID = 4, StudentName = "Ram" },
             new Student() { StudentID = 5, StudentName = "Ron" }
         };

             bool isEqual = studentList1.SequenceEqual(studentList2, new StudentComparer());

             Console.WriteLine(isEqual);

             Console.ReadLine();
         }
     }
     public class Student
     {

         public int StudentID { get; set; }
         public string StudentName { get; set; }
     }
     class StudentComparer : IEqualityComparer<Student>
     {
         public bool Equals(Student x, Student y)
         {
             if (x.StudentID == y.StudentID && x.StudentName.ToLower() == y.StudentName.ToLower())
                 return true;

             return false;
         }

         public int GetHashCode(Student obj)
         {
             return obj.GetHashCode();
         }
     }

   // }
}