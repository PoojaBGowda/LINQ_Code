﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concat
{
    class Program
    {
        static void Main(string[] args)
        {

            //Linq94();
            //Linq95();
            //concat1();
            concat2();

        }
        public static void concat1()
        {
            IList<string> collection1 = new List<string>() { "One", "Two", "Three" };
            IList<string> collection2 = new List<string>() { "Five", "Six" };

            var concateResult = collection1.Concat(collection2);

            foreach (string str in concateResult)
                Console.WriteLine(str);
            Console.ReadLine();
        }

        public static void concat2()
        {
            IList<int> collection1 = new List<int>() { 1, 2, 3 };
            IList<int> collection2 = new List<int>() { 4, 5, 6 };

            var collection3 = collection1.Concat(collection2);

            foreach (int i in collection3)
                Console.WriteLine(i);
            Console.ReadLine();
        }

        public static void Linq94()
        {
            int[] numbersA = { 0, 2, 4, 5, 6, 8, 9 };
            int[] numbersB = { 1, 3, 5, 7, 8 };

            var allNumbers = numbersA.Concat(numbersB);

            Console.WriteLine("All numbers from both arrays:");
            foreach (var n in allNumbers)
            {
                Console.WriteLine(n);
            }

            Console.ReadLine();
        }

        public static void Linq95()
        {
            DataClasses1DataContext db = new DataClasses1DataContext(); //Acquire the data
            var query = db.Employees;
            var customers = db.Customers;
            var products = db.Products;

            //List<Customer> customers = query1;
            //List<Product> products = GetProductList();

            var customerNames =
                from c in customers
                select c.CompanyName;
            var productNames =
                from p in products
                select p.ProductName;

            var allNames = customerNames.Concat(productNames);

            Console.WriteLine("Customer and product names:");
            foreach (var n in allNames)
            {
                Console.WriteLine(n);
            }
            Console.ReadLine();
        }
    }

    }


