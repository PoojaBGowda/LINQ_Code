﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SetOperator
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numberSet1 = { 0, 2, 2, 4, 5, 6, 6, 8, 9, 4 };
            int[] numberSet2 = { 1, 3, 5, 7, 8, 4 };




            var UniqeNumbers = numberSet1.Distinct();
            Console.WriteLine("Unique numbers from both arrays:");
            foreach (var item in UniqeNumbers)
            {
                Console.WriteLine(item);
            }

            var UnionOfNumbers = numberSet1.Union(numberSet2);

            Console.WriteLine("Union of both number set 1 and 2:");
            foreach (var item in UnionOfNumbers)
            {
                Console.WriteLine(item);
            }

            var CommonNumbers = numberSet1.Intersect(numberSet2);

            Console.WriteLine("Common numbers shared by both arrays:");
            foreach (var item in CommonNumbers)
            {
                Console.WriteLine(item);
            }

            var UniqueNumInSet1 = numberSet1.Except(numberSet2);

            Console.WriteLine("Numbers in first array but not in second array:");
            foreach (var item in UniqueNumInSet1)
            {
                Console.WriteLine(item);
            }

            Console.ReadLine();
        }

    }
}