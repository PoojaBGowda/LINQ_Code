﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace range
{
    class Program
    {
        static void Main(string[] args)
        {
            var numbers =
       from n in Enumerable.Range(200, 30)

       select new { Number = n, OddEven = n % 2 == 1 ? "odd" : "even" };

            foreach (var n in numbers)
            {
                Console.WriteLine("The number {0} is {1}.", n.Number, n.OddEven);
                Console.ReadLine();
            }
        }
    }
}
