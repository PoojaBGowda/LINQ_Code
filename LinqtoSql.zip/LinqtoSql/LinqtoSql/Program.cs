﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using LinqtoSql;

namespace LinqtoSql
{
    class LinqToSQLCRUD
    {
        static void Main(string[] args)
        {
            string connectString =ConfigurationManager.ConnectionStrings["LinqtoSql.Properties.Settings.NorthwindConnectionString"].ToString();

            DataClasses1DataContext db = new DataClasses1DataContext(connectString);

            Category category = new Category();

            /*Insert onSubmit
             
            //Create new Category

            category.CategoryID = 11;
            category.CategoryName = "Chocolates";
            category.Description = "All types of chocolates";

            db.Categories.InsertOnSubmit(category);

             db.SubmitChanges();

             */


            /*  Delete the row from the table
             
             var deletedetails = from details in db.Categories
                         where details.CategoryID == 10
                         select details;

            foreach (var detail in deletedetails)
            {
                db.Categories.DeleteOnSubmit(detail);
            }

             db.SubmitChanges();
             */

            //  Update the Datasource

            var updatedetails = db.Categories.FirstOrDefault(e => e.CategoryName.Equals("Beverages"));
            if (updatedetails != null)
            {
                updatedetails.CategoryName = "Beverage";
              //  db.Categories.InsertOnSubmit(updatedetails);

                //Save changes to Database.
                db.SubmitChanges();

            }










            //Get new Inserted Employee            
            Category insertedCategory = db.Categories.FirstOrDefault(e => e.CategoryName.Equals("Beverage"));

            Console.WriteLine("CategoryID = {0} , CategoryName = {1} ",
                              insertedCategory.CategoryID, insertedCategory.CategoryName);

            Console.WriteLine("\nPress any key to continue.");
            Console.ReadKey();
        }
    }
}
