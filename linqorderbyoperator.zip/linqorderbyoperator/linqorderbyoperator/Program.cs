﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace linqorderbyoperator
{
    class Program
    {
        static void Main(string[] args)
        {
            //string[] words = { "cherry", "apple", "blueberry" };

            //var sortedWords =
            //    (from w in words
            //    orderby w.Length
            //    select w).Reverse();

            //Console.WriteLine("The sorted list of words:");
            //foreach (var w in sortedWords)
            //{
            //    Console.WriteLine(w);
            //}
            DataClasses1DemoDataContext db = new DataClasses1DemoDataContext();
            List<Product> avr = db.GetTable<Product>().ToList();
            var res = from a in avr
                      where a.CategoryID == 3
                      orderby a.ProductName
                      select a.ProductName;
            var rev = (from a in avr
                      where a.CategoryID==3
                      orderby a.ProductName
                      select a.ProductName).Reverse();
            Console.WriteLine("before..");
            foreach (var item in res)
            {
                Console.WriteLine(  item);
            }
            Console.WriteLine("after..");
            foreach (var item in rev)
            {
                Console.WriteLine(item);
            }
        }
    }
}
