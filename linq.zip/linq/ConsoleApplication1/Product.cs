﻿namespace ConsoleApplication1
{
   public class Product
    {
        public string Category { get;  set; }
        public int ProductId { get;  set; }
        public string ProductName { get;  set; }
    }
}