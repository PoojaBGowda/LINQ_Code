﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {
            /*first page with cndtn*/
            //string[] strings = { "zero", "one", "two", "three", "four", "five", "six" };
            //string startsWith = strings.First(s => s[0] == 'o');
            //Console.WriteLine("A string starting with 'o':{0}", startsWith);

            /*FirstorDefault*/
            //int[] numbers = { };
            //int firstNumOrDefault = numbers.FirstOrDefault();


            //Console.WriteLine(firstNumOrDefault);

            /*Element At*/
            int[] numbers = { 1, 4, 8, 3, 9, 8, 6, 7, 2, 0 };

            int fourthLowNum = (
                from n in numbers
                where n > 1
                select n)
                    .ElementAt(1);

            Console.WriteLine("Second number > 1: {0}", fourthLowNum);


            Console.ReadKey();


        }
    }
}
